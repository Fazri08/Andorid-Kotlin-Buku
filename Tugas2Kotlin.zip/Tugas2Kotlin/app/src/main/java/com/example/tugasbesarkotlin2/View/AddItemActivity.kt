package com.example.tugasbesarkotlin2.View

import android.arch.persistence.room.Room
import android.content.Intent
import android.os.AsyncTask
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import com.example.tugasbesarkotlin2.Database.BukuDatabase
import com.example.tugasbesarkotlin2.Models.Buku
import com.example.tugasbesarkotlin2.R

class AddItemActivity : AppCompatActivity() {

    internal lateinit var nama: EditText
    internal lateinit var pengarang: EditText
    internal lateinit var button: Button
    internal lateinit var db: BukuDatabase

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_item)

        db = Room.databaseBuilder(applicationContext, BukuDatabase::class.java!!, "production")
            .build()

        nama = findViewById<View>(R.id.nama) as EditText
        pengarang = findViewById<View>(R.id.pengarang) as EditText
        button = findViewById<View>(R.id.button) as Button


        val db = Room.databaseBuilder(applicationContext, BukuDatabase::class.java!!, "production")
            .build()

        button.setOnClickListener {
            if (nama.text.toString() != "" && pengarang.text.toString() != "") {

                val todoListItem = Buku(nama.text.toString(), pengarang.text.toString())
                //save the item before leaving the activity


                AsyncTask.execute { db.databaseInterface().insertAll(todoListItem) }


                val i = Intent(this@AddItemActivity, MainActivity::class.java)
                startActivity(i)

                finish()
            }
        }
    }
}