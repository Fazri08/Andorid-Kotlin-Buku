package com.example.tugasbesarkotlin2.Database

import android.arch.persistence.room.Dao
import android.arch.persistence.room.Insert
import android.arch.persistence.room.Query
import com.example.tugasbesarkotlin2.Models.Buku

@Dao
interface BukuDao {
    @get:Query("SELECT * FROM buku")
    val allItems: List<Buku>

    @Insert
    fun insertAll(vararg bukus: Buku)
}
