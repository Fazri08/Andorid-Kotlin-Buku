package com.example.tugasbesarkotlin2.View

import android.app.ProgressDialog
import android.arch.persistence.room.Room
import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.text.TextUtils
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import com.example.tugasbesarkotlin2.Database.UserDao
import com.example.tugasbesarkotlin2.Database.UserDatabase
import com.example.tugasbesarkotlin2.Models.User
import com.example.tugasbesarkotlin2.R

class SignUpActivity : AppCompatActivity() {

    private var edtName: EditText? = null
    private var edtLastName: EditText? = null
    private var edtEmail: EditText? = null
    private var edtPassword: EditText? = null

    private var btCancel: Button? = null
    private var btRegister: Button? = null

    private var userDao: UserDao? = null

    private var progressDialog: ProgressDialog? = null

    private val isEmpty: Boolean
        get() = if (TextUtils.isEmpty(edtEmail!!.text.toString()) ||
            TextUtils.isEmpty(edtPassword!!.text.toString()) ||
            TextUtils.isEmpty(edtName!!.text.toString()) ||
            TextUtils.isEmpty(edtLastName!!.text.toString())
        ) {
            true
        } else {
            false
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_sign_up)

        progressDialog = ProgressDialog(this)
        progressDialog!!.setCancelable(false)
        progressDialog!!.setMessage("Registering...")
        progressDialog!!.setProgressStyle(ProgressDialog.STYLE_SPINNER)
        progressDialog!!.progress = 0


        edtName = findViewById(R.id.nameinput)
        edtLastName = findViewById(R.id.lastnameinput)
        edtEmail = findViewById(R.id.emailinput)
        edtPassword = findViewById(R.id.passwordinput)

        btCancel = findViewById(R.id.btCancel)
        btRegister = findViewById(R.id.btRegister)

        userDao = Room.databaseBuilder(this, UserDatabase::class.java!!, "mi-database.db")
            .allowMainThreadQueries()
            .build()
            .userDao

        btCancel!!.setOnClickListener {
            startActivity(Intent(this@SignUpActivity, LoginActivity::class.java))
            finish()
        }

        btRegister!!.setOnClickListener {
            if (!isEmpty) {

                progressDialog!!.show()

                Handler().postDelayed({
                    val user = User(
                        edtName!!.text.toString(), edtLastName!!.text.toString(),
                        edtEmail!!.text.toString(), edtPassword!!.text.toString()
                    )
                    userDao!!.insert(user)
                    progressDialog!!.dismiss()
                    startActivity(Intent(this@SignUpActivity, LoginActivity::class.java))
                }, 1000)

            } else {
                Toast.makeText(this@SignUpActivity, "Empty Fields", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
