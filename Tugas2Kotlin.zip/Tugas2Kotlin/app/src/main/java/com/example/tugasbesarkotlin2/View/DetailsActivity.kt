package com.example.tugasbesarkotlin2.View

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView
import com.example.tugasbesarkotlin2.R

class DetailsActivity : AppCompatActivity() {
    internal lateinit var id: TextView
    internal lateinit var nama: TextView
    internal lateinit var pengarang: TextView


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_details)

        id = findViewById(R.id.id)
        nama = findViewById(R.id.nama)
        pengarang = findViewById(R.id.pengarang)

        val intent = intent

        id.text = intent.getStringExtra("id")
        id.tag = id.keyListener
        id.keyListener = null
        nama.text = intent.getStringExtra("nama")
        pengarang.text = intent.getStringExtra("pengarang")

    }
}
