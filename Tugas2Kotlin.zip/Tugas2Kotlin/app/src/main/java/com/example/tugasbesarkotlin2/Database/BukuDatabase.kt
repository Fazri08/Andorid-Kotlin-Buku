package com.example.tugasbesarkotlin2.Database

import android.arch.persistence.db.SupportSQLiteOpenHelper
import android.arch.persistence.room.Database
import android.arch.persistence.room.DatabaseConfiguration
import android.arch.persistence.room.InvalidationTracker
import android.arch.persistence.room.RoomDatabase
import com.example.tugasbesarkotlin2.Models.Buku

@Database(entities = [Buku::class], version = 1)
abstract class BukuDatabase : RoomDatabase() {

    abstract fun databaseInterface(): BukuDao

}
