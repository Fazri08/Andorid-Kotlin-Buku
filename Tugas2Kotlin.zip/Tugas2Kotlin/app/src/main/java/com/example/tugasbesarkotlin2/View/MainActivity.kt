package com.example.tugasbesarkotlin2.View

import android.arch.persistence.room.Room
import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.design.widget.FloatingActionButton
import android.support.v7.widget.LinearLayoutManager
import android.support.v7.widget.RecyclerView
import android.widget.TextView
import com.example.tugasbesarkotlin2.Adapter.BukuAdapter
import com.example.tugasbesarkotlin2.Database.BukuDatabase
import com.example.tugasbesarkotlin2.Models.Buku
import com.example.tugasbesarkotlin2.Models.User
import com.example.tugasbesarkotlin2.R

class MainActivity : AppCompatActivity() {

    internal lateinit var fab: FloatingActionButton
    internal lateinit var items: List<Buku>

//    private var tvUser: TextView? = null
//
//    private var user: User? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

//        user = intent.getSerializableExtra("User") as User

//        tvUser = findViewById(R.id.tvUser)

//        if (user != null) {
//            tvUser!!.text = "WELCOME " + user!!.name + " " + user!!.lastName
//        }

        val db = Room.databaseBuilder(applicationContext, BukuDatabase::class.java!!, "production")
            .build()

        val r = Runnable {
            items = db.databaseInterface().allItems
            recyclerView = findViewById(R.id.recyclerview) as RecyclerView
            recyclerView.layoutManager = LinearLayoutManager(application)
            adapter = BukuAdapter(items)
            adapter.notifyDataSetChanged()
            recyclerView.adapter = adapter
        }

        val newThread = Thread(r)
        newThread.start()

        fab = findViewById(R.id.fab) as FloatingActionButton

        fab.setOnClickListener {
            val i = Intent(this@MainActivity, AddItemActivity::class.java)
            startActivity(i)
            finish()
        }
    }

    companion object {
        lateinit var recyclerView: RecyclerView
        lateinit var adapter: RecyclerView.Adapter<*>
    }
}
