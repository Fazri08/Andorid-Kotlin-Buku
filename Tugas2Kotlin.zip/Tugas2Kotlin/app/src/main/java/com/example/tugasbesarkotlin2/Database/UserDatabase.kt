package com.example.tugasbesarkotlin2.Database

import android.arch.persistence.room.Database
import android.arch.persistence.room.RoomDatabase
import com.example.tugasbesarkotlin2.Models.User

@Database(entities = [User::class], version = 1, exportSchema = false)
abstract class UserDatabase : RoomDatabase() {

    abstract val userDao: UserDao

}
