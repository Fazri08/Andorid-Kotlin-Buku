package com.example.tugasbesarkotlin2.Adapter

import android.content.Intent
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import com.example.tugasbesarkotlin2.Models.Buku
import com.example.tugasbesarkotlin2.R
import com.example.tugasbesarkotlin2.View.DetailsActivity

class BukuAdapter(internal var items: List<Buku>) : RecyclerView.Adapter<BukuAdapter.ViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): BukuAdapter.ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_row, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: BukuAdapter.ViewHolder, position: Int) {
        holder.nama.setText(items[position].nama)
        holder.pengarang.setText(items[position].pengarang)

        holder.itemView.setOnClickListener { view ->
            val mIntent = Intent(view.context, DetailsActivity::class.java)
            mIntent.putExtra("id", items[position].id)
            mIntent.putExtra("nama", items[position].nama)
            mIntent.putExtra("pengarang", items[position].pengarang)
            view.context.startActivity(mIntent)
        }
    }

    override fun getItemCount(): Int {
        return items.size
    }

    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        var nama: TextView
        var pengarang: TextView

        init {
            nama = itemView.findViewById(R.id.nama)
            pengarang = itemView.findViewById(R.id.pengarang)
        }
    }
}
