package com.example.tugasbesarkotlin2.Models

import android.arch.persistence.room.ColumnInfo
import android.arch.persistence.room.Entity
import android.arch.persistence.room.PrimaryKey

@Entity
class Buku {

    @PrimaryKey(autoGenerate = true)
    var id: Int = 0

    @ColumnInfo(name = "nama")
    var nama: String? = null

    @ColumnInfo(name = "pengarang")
    var pengarang: String? = null

    constructor() {

    }

    constructor(nama: String, pengarang: String) {
        this.nama = nama
        this.pengarang = pengarang
    }
}
